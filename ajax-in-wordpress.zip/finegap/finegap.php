<?php

/**
 * Plugin Name: Finegap
 * Plugin URI: https://finegap.com/
 * Description: Demo finegap plugin.
 * Version: 1.0
 * Requires PHP: 5.3
 * Author: Faheem
 */ 

function fgp_plugin_activated() {}


function fgp_shortcode()
{
    ob_start();

    echo "Shortcode is working";
    
    $contents = ob_get_contents();
    
    ob_end_clean();

    ?>

    <script>
        window.ajaxUrl = "<?php echo (admin_url('admin-ajax.php')); ?>";
    </script>

    <?php
    return $contents;
}

function fgp_enqueue_js()
{
    
    wp_enqueue_script('ajaxRequest', plugins_url('/ajaxRequest.js', __FILE__), array('jquery'), '1.0', true);
}

function fgp_ajax_callback() 
{

    $response = [
        "code" => 1
    ];

	die(json_encode($response));

}


// register_activation_hook(__FILE__, 'fgp_plugin_activated');

add_shortcode('finegap', 'fgp_shortcode');
add_action('wp_enqueue_scripts', 'fgp_enqueue_js');
add_action("wp_ajax_nopriv_action_abc", "fgp_ajax_callback");
add_action("wp_ajax_action_abc", "fgp_ajax_callback");


