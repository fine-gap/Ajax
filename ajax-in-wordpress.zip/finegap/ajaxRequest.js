jQuery(document).ready(function ($) {
    let _data = {
        action: "action_abc",
        someData: "abc",
      };
  $.ajax({
    url: ajaxUrl, // Point to server-side controller method.
    dataType: 'json', // What to expect back from the server.
    data: _data,
    method: 'POST',
    // processData: false, // Don't process the data
    // contentType: false, // Don't set content type
  }).error(function (response) {
    console.log(response);
    // alert('Connection failed.' + JSON.stringify(response.statusText));
  });
});
